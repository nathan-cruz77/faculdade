import sys
import json

file_list = sys.argv[1:]

data = []
for f in file_list:
    with open(f, 'r') as data_in:
        data.extend(json.load(data_in))

with open('all.json', 'w') as data_out:
    json.dump(data, data_out, indent=True)
